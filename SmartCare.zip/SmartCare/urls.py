from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.main, name='main'),
    path('schedule/', views.schedule, name='schedule'),
    path('intake-verification/', views.intake_verification, name='intake_verification'),
    path('detect-gesture/', views.detect_gesture, name='detect_gesture'),  # For real-time detection
    path('verify-intake/', views.verify_intake, name='verify_intake'),      # For manual verification
    path('add_medication/', views.add_medication, name='add_medication'),
    path('mark-taken/<int:schedule_id>/', views.mark_taken, name='mark_taken'),
    path('api/schedule/<str:date_str>/', views.get_schedule_api, name='api_schedule'),
    path('pending-approval/', views.pending_approval, name='pending_approval'),
    path('approve/<str:token>/', views.approve_medication, name='approve_medication'),
    path('deny/<str:token>/', views.deny_medication, name='deny_medication'),
    path('request-remove/<int:schedule_id>/', views.request_remove_medication, name='request_remove'),
    path('approve-removal/<str:token>/<int:schedule_id>/', views.approve_removal, name='approve_removal'),
    path('deny-removal/<str:token>/<int:schedule_id>/', views.deny_removal, name='deny_removal'),
    # path('api/notification-status/', views.get_notification_data_json, name='notification_status'),
]