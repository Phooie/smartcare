import json
import secrets
import base64
import cv2
import numpy as np
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
import os
import urllib.request
import time
from django.shortcuts import render, get_object_or_404, redirect
from django.utils import timezone
from django.contrib import messages
from django.http import JsonResponse, StreamingHttpResponse
from django.views.decorators.csrf import csrf_protect, csrf_exempt
from django.core.mail import send_mail
from django.conf import settings
from django.urls import reverse
from django.db import models
from datetime import date, datetime, timedelta
from .models import Medication, Schedule, MedicationLog, PendingMedication, FoodInteraction, DrugInteraction, IntakeLog
from .interaction_utils import check_drug_interactions

# ==================== HAND-TO-MOUTH DETECTION ====================
hand_landmarker = None
face_landmarker = None

def initialize_mediapipe():
    """Initialize MediaPipe models"""
    global hand_landmarker, face_landmarker
    
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        hand_model_path = os.path.join(base_dir, "hand_landmarker.task")
        face_model_path = os.path.join(base_dir, "face_landmarker.task")
        
        if not os.path.exists(hand_model_path):
            hand_url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
            urllib.request.urlretrieve(hand_url, hand_model_path)
            print("Downloaded hand_landmarker.task")
        
        if not os.path.exists(face_model_path):
            face_url = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
            urllib.request.urlretrieve(face_url, face_model_path)
            print("Downloaded face_landmarker.task")
        
        hand_options = vision.HandLandmarkerOptions(
            base_options=python.BaseOptions(model_asset_path=hand_model_path),
            num_hands=2,
            min_hand_detection_confidence=0.7,
            min_tracking_confidence=0.5
        )
        hand_landmarker = vision.HandLandmarker.create_from_options(hand_options)
        
        face_options = vision.FaceLandmarkerOptions(
            base_options=python.BaseOptions(model_asset_path=face_model_path),
            num_faces=1,
            min_face_detection_confidence=0.7,
            min_tracking_confidence=0.5
        )
        face_landmarker = vision.FaceLandmarker.create_from_options(face_options)
        
        print("✅ MediaPipe initialized successfully")
        return True
    except Exception as e:
        print(f"Error initializing MediaPipe: {e}")
        return False


def detect_hand_to_mouth_from_frame(frame):
    """Detect hand-to-mouth gesture from frame"""
    global hand_landmarker, face_landmarker
    
    if hand_landmarker is None or face_landmarker is None:
        return False, None
    
    try:
        INDEX_TIP = 8
        
        h, w = frame.shape[:2]
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
        
        hand_result = hand_landmarker.detect(mp_image)
        face_result = face_landmarker.detect(mp_image)
        
        mouth_center = None
        pill_detected = False
        
        if face_result and face_result.face_landmarks:
            face_landmarks = face_result.face_landmarks[0]
            
            left_corner = face_landmarks[78]
            right_corner = face_landmarks[308]
            upper_lip = face_landmarks[13]
            lower_lip = face_landmarks[14]
            
            mouth_center = (
                int(((left_corner.x + right_corner.x) / 2) * w),
                int(((upper_lip.y + lower_lip.y) / 2) * h)
            )
        
        if hand_result and hand_result.hand_landmarks and mouth_center:
            for hand_landmarks in hand_result.hand_landmarks:
                index_tip = hand_landmarks[INDEX_TIP]
                finger_pos = (int(index_tip.x * w), int(index_tip.y * h))
                
                distance = np.sqrt((finger_pos[0] - mouth_center[0])**2 + 
                                  (finger_pos[1] - mouth_center[1])**2)
                
                threshold = w * 0.08
                if distance < threshold:
                    pill_detected = True
                    break
        
        return pill_detected, mouth_center
        
    except Exception as e:
        print(f"Detection error: {e}")
        return False, None


# ==================== UPDATE STATUS FUNCTION ====================

def update_all_schedule_statuses():
    """Update statuses for all active schedules - resets daily and marks missed if time passed"""
    today = date.today()
    now = timezone.now()
    
    schedules = Schedule.objects.filter(
        status='active',
        start_date__lte=today,
        medication__pills_remaining__gt=0
    ).select_related('medication')
    
    updated_count = 0
    missed_count = 0
    reset_count = 0
    
    for schedule in schedules:
        if not schedule.is_active_today(today):
            continue
            
        # Check if there's already a log for today
        today_logs = IntakeLog.objects.filter(
            schedule=schedule,
            date=today
        )
        
        # ===== RESET STATUS FOR NEW DAY =====
        # If no log for today and status is from yesterday, reset to pending
        if not today_logs.exists() and schedule.intake_status != 'pending':
            schedule.intake_status = 'pending'
            schedule.save()
            reset_count += 1
            continue
        
        # Skip if already verified today
        if schedule.intake_status == 'verified':
            continue
        
        # Skip if already logged for today (but not verified)
        if today_logs.exists():
            continue
            
        scheduled_datetime = datetime.combine(today, schedule.scheduled_time)
        scheduled_datetime = timezone.make_aware(scheduled_datetime)
        time_diff_minutes = (now - scheduled_datetime).total_seconds() / 60
        
        # Only auto-mark as missed after 60 minutes
        if time_diff_minutes > 60:
            # Mark as missed
            schedule.intake_status = 'missed'
            schedule.save()
            
            # DO NOT change pills_remaining - the pill stays in the dispenser
            # The pill was not consumed, so it remains available for future doses
            
            IntakeLog.objects.create(
                schedule=schedule,
                medication=schedule.medication,
                scheduled_time=scheduled_datetime,
                status='missed',
                is_verified=False,
                minutes_late=int(time_diff_minutes),
                notes=f'Auto-marked as missed. Pill not consumed - remains in dispenser.'
            )
            updated_count += 1
            missed_count += 1
    
    return {
        'updated_count': updated_count,
        'missed_count': missed_count,
        'reset_count': reset_count,
    }


# ==================== VIEWS ====================

def main(request):
    """Dashboard with real data"""
    today = date.today()
    
    # Update statuses first
    update_all_schedule_statuses()
    
    all_schedules = Schedule.objects.filter(
        status='active',
        start_date__lte=today,
        medication__pills_remaining__gt=0
    ).select_related('medication')
    
    today_schedules = [s for s in all_schedules if s.is_active_today(today)]
    
    total_today = len(today_schedules)
    taken_today = len([s for s in today_schedules if s.intake_status == 'verified'])
    compliance = int((taken_today / total_today) * 100) if total_today > 0 else 0
    
    drug_names = list(set([s.medication.name.lower().strip() for s in today_schedules]))
    drug_interactions = check_drug_interactions(drug_names)
    
    food_interactions = []
    for med_name in drug_names:
        food_ints = FoodInteraction.objects.filter(
            drug_name__icontains=med_name
        )
        for fi in food_ints:
            food_interactions.append({
                'medication': med_name,
                'interaction_text': fi.interaction_text,
                'interaction_type': fi.get_interaction_type_display(),
                'severity': fi.get_severity_display(),
                'drug_name': fi.drug_name
            })
    
    low_stock_meds = Medication.objects.filter(
        pills_remaining__lte=models.F('low_quantity_threshold'),
        pills_remaining__gt=0
    )
    out_of_stock_meds = Medication.objects.filter(pills_remaining=0)
    
    context = {
        'today_total': total_today,
        'today_taken': taken_today,
        'compliance': compliance,
        'drug_interactions': drug_interactions,
        'food_interactions': food_interactions,
        'low_stock_count': low_stock_meds.count(),
        'out_of_stock_count': out_of_stock_meds.count(),
        'today_schedules': today_schedules[:5],
        'has_drug_interactions': len(drug_interactions) > 0,
        'has_food_interactions': len(food_interactions) > 0,
    }
    return render(request, 'main.html', context)


def schedule(request):
    """Display today's medication schedule with separate interaction sections"""
    # Update statuses first (this will reset for new day and mark missed)
    update_all_schedule_statuses()
    
    today = date.today()
    
    # Get ALL active schedules first
    all_schedules = Schedule.objects.filter(
        status='active',
        start_date__lte=today,
        medication__pills_remaining__gt=0
    ).select_related('medication').order_by('scheduled_time')
    
    # Filter to only those active today
    today_schedules = []
    for s in all_schedules:
        if s.is_active_today(today):
            today_schedules.append(s)
    
    # If no schedules for today, show empty state
    if not today_schedules:
        context = {
            'schedules': [],
            'compliance': 0,
            'total_pills': 0,
            'taken_pills': 0,
            'today': today,
            'drug_interactions': [],
            'food_interactions': [],
            'has_drug_interactions': False,
            'has_food_interactions': False,
            'next_medication': None,
            'pre_notification': None,
            'graph_labels_json': json.dumps([]),
            'medication_datasets_json': json.dumps([]),
            'has_graph_data': False,
        }
        return render(request, 'schedule.html', context)
    
    # ====== GENERATE GRAPH DATA ======
    graph_labels = []
    medication_datasets = []
    
    # Get unique medication IDs from today's schedules
    medication_ids = list(set([s.medication.id for s in today_schedules]))
    
    if medication_ids:
        # Build data for last 14 days
        for i in range(13, -1, -1):
            check_date = today - timedelta(days=i)
            graph_labels.append(check_date.strftime('%a %d'))
        
        colors = ['#2563eb', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316']
        
        for idx, med_id in enumerate(medication_ids):
            try:
                med = Medication.objects.get(id=med_id)
                data_points = []
                
                for i in range(13, -1, -1):
                    check_date = today - timedelta(days=i)
                    count = IntakeLog.objects.filter(
                        medication=med,
                        date=check_date,
                        status__in=['on_time', 'late', 'verified_camera', 'verified_manual']
                    ).count()
                    data_points.append(count)
                
                medication_datasets.append({
                    'label': med.name,
                    'data': data_points,
                    'borderColor': colors[idx % len(colors)],
                    'backgroundColor': colors[idx % len(colors)] + '33',
                    'borderWidth': 2,
                    'pointRadius': 3,
                    'pointBackgroundColor': colors[idx % len(colors)],
                    'tension': 0.3,
                    'fill': False,
                })
            except Medication.DoesNotExist:
                pass
    
    # ====== DRUG INTERACTIONS ======
    drug_names = list(set([s.medication.name.lower().strip() for s in today_schedules]))
    drug_interactions = check_drug_interactions(drug_names)
    
    # ====== FOOD INTERACTIONS ======
    food_interactions = []
    for med in today_schedules:
        med_name = med.medication.name.lower().strip()
        food_ints = FoodInteraction.objects.filter(
            drug_name__icontains=med_name
        )
        for fi in food_ints:
            food_interactions.append({
                'medication': med.medication.name,
                'food_item': fi.drug_name,
                'interaction_text': fi.interaction_text,
                'interaction_type': fi.get_interaction_type_display(),
                'severity': fi.get_severity_display(),
            })
    
    # ====== STATS ======
    total = len(today_schedules)
    taken = len([s for s in today_schedules if s.intake_status == 'verified'])
    compliance = int((taken / total) * 100) if total > 0 else 0
    
    # ====== NEXT MEDICATION & PRE-NOTIFICATION ======
    next_medication = None
    pre_notification = None
    now = timezone.now()
    
    for schedule in today_schedules:
        # Only show notification for pending schedules
        if schedule.intake_status == 'pending':
            scheduled_datetime = datetime.combine(today, schedule.scheduled_time)
            scheduled_datetime = timezone.make_aware(scheduled_datetime)
            
            time_diff_minutes = (now - scheduled_datetime).total_seconds() / 60
            
            # Pre-notification (5 minutes before)
            if -5 <= time_diff_minutes < 0:
                time_until_seconds = abs(time_diff_minutes) * 60
                hours = int(time_until_seconds // 3600)
                minutes = int((time_until_seconds % 3600) // 60)
                seconds = int(time_until_seconds % 60)
                pre_countdown = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
                
                pre_notification = {
                    'schedule_id': schedule.id,
                    'medication_name': schedule.medication.name,
                    'dosage': schedule.medication.dosage_count,
                    'scheduled_time': schedule.scheduled_time.strftime('%I:%M %p'),
                    'target_datetime': scheduled_datetime.isoformat(),
                    'countdown': pre_countdown,
                }
            
            # Main notification (0 to 60 minutes after)
            if 0 <= time_diff_minutes <= 60:
                is_late = time_diff_minutes > 15
                time_remaining_seconds = (60 - time_diff_minutes) * 60
                hours = int(time_remaining_seconds // 3600)
                minutes = int((time_remaining_seconds % 3600) // 60)
                seconds = int(time_remaining_seconds % 60)
                countdown = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
                
                next_medication = {
                    'schedule_id': schedule.id,
                    'medication_name': schedule.medication.name,
                    'dosage': schedule.medication.dosage_count,
                    'scheduled_time': schedule.scheduled_time.strftime('%I:%M %p'),
                    'target_datetime': scheduled_datetime.isoformat(),
                    'countdown': countdown,
                    'is_late': is_late,
                    'time_elapsed_minutes': int(time_diff_minutes),
                    'time_remaining_minutes': int(60 - time_diff_minutes),
                }
                break
    
    # ====== CONTEXT ======
    context = {
        'schedules': today_schedules,
        'compliance': compliance,
        'total_pills': total,
        'taken_pills': taken,
        'today': today,
        'drug_interactions': drug_interactions,
        'food_interactions': food_interactions,
        'has_drug_interactions': len(drug_interactions) > 0,
        'has_food_interactions': len(food_interactions) > 0,
        'next_medication': next_medication,
        'pre_notification': pre_notification,
        # Graph data
        'graph_labels_json': json.dumps(graph_labels),
        'medication_datasets_json': json.dumps(medication_datasets),
        'has_graph_data': len(medication_datasets) > 0,
    }
    return render(request, 'schedule.html', context)


def intake_verification(request):
    """Intake verification page with camera and detection"""
    today = date.today()
    now = timezone.now()
    
    # Update statuses first
    update_all_schedule_statuses()
    
    # Also handle missed status for any schedules that might have been missed
    schedules_to_check = Schedule.objects.filter(
        status='active',
        start_date__lte=today,
        medication__pills_remaining__gt=0
    ).select_related('medication')
    
    for schedule in schedules_to_check:
        if not schedule.is_active_today(today):
            continue
            
        scheduled_datetime = datetime.combine(today, schedule.scheduled_time)
        scheduled_datetime = timezone.make_aware(scheduled_datetime)
        time_diff_minutes = (now - scheduled_datetime).total_seconds() / 60
        
        # Only mark as missed after 60 minutes
        if time_diff_minutes > 60:
            today_logs = IntakeLog.objects.filter(
                schedule=schedule,
                date=today
            )
            
            if not today_logs.exists() and schedule.intake_status != 'verified':
                if schedule.intake_status != 'missed':
                    IntakeLog.objects.create(
                        schedule=schedule,
                        medication=schedule.medication,
                        scheduled_time=scheduled_datetime,
                        status='missed',
                        is_verified=False,
                        minutes_late=int(time_diff_minutes),
                        notes=f'Auto-marked as missed. Pill not consumed - remains in dispenser.'
                    )
                    schedule.intake_status = 'missed'
                    schedule.save()
    
    # Get current active schedule for today
    current_schedule = None
    current_schedule_id = None
    no_medication_today = True
    next_schedule_display = None
    is_verification_time = False
    
    active_schedules = Schedule.objects.filter(
        status='active',
        start_date__lte=today,
        medication__pills_remaining__gt=0
    ).select_related('medication').order_by('scheduled_time')
    
    today_schedules = [s for s in active_schedules if s.is_active_today(today)]
    
    if today_schedules:
        no_medication_today = False
        
        # Check if any schedule is in the verification window (5 min before to 60 min after)
        for schedule in today_schedules:
            scheduled_datetime = datetime.combine(today, schedule.scheduled_time)
            scheduled_datetime = timezone.make_aware(scheduled_datetime)
            time_diff_minutes = (now - scheduled_datetime).total_seconds() / 60
            
            # Verification window: 5 minutes before to 60 minutes after
            is_in_window = -5 <= time_diff_minutes <= 60
            
            today_logs = IntakeLog.objects.filter(
                schedule=schedule,
                date=today
            )
            
            if is_in_window and not today_logs.exists() and schedule.intake_status != 'verified':
                current_schedule = schedule
                current_schedule_id = schedule.id
                next_schedule_display = schedule.scheduled_time.strftime('%I:%M %p')
                if schedule.dose_number > 1:
                    next_schedule_display += f" (Dose {schedule.dose_number})"
                is_verification_time = True
                break
        
        # If no schedule in window, find the next upcoming for display
        if not current_schedule:
            for schedule in today_schedules:
                scheduled_datetime = datetime.combine(today, schedule.scheduled_time)
                scheduled_datetime = timezone.make_aware(scheduled_datetime)
                time_diff_minutes = (now - scheduled_datetime).total_seconds() / 60
                
                if time_diff_minutes < -5:  # Future schedule (more than 5 min away)
                    next_schedule_display = schedule.scheduled_time.strftime('%I:%M %p')
                    if schedule.dose_number > 1:
                        next_schedule_display += f" (Dose {schedule.dose_number})"
                    break
            
            # If all passed, show tomorrow's first
            if not next_schedule_display:
                tomorrow = today + timedelta(days=1)
                tomorrow_schedules = Schedule.objects.filter(
                    status='active',
                    start_date__lte=tomorrow,
                    medication__pills_remaining__gt=0
                ).order_by('scheduled_time')
                for schedule in tomorrow_schedules:
                    if schedule.is_active_today(tomorrow):
                        next_schedule_display = schedule.scheduled_time.strftime('%I:%M %p') + ' (Tomorrow)'
                        if schedule.dose_number > 1:
                            next_schedule_display += f" (Dose {schedule.dose_number})"
                        break
    
    recent_logs = IntakeLog.objects.filter(
        date__gte=today - timedelta(days=7)
    ).select_related('medication').order_by('-date')[:10]
    
    graph_labels = []
    on_time_data = []
    late_data = []
    missed_data = []
    
    for i in range(6, -1, -1):
        check_date = today - timedelta(days=i)
        graph_labels.append(check_date.strftime('%a %d'))
        
        day_logs = IntakeLog.objects.filter(date=check_date)
        on_time_count = day_logs.filter(status='on_time').count()
        late_count = day_logs.filter(status='late').count()
        missed_count = day_logs.filter(status='missed').count()
        
        on_time_data.append(on_time_count)
        late_data.append(late_count)
        missed_data.append(missed_count)
    
    context = {
        'current_medication': current_schedule,
        'current_schedule_id': current_schedule_id,
        'recent_logs': recent_logs,
        'graph_labels_json': json.dumps(graph_labels),
        'on_time_data_json': json.dumps(on_time_data),
        'late_data_json': json.dumps(late_data),
        'missed_data_json': json.dumps(missed_data),
        'is_verification_time': is_verification_time,
        'no_medication_today': no_medication_today,
        'next_schedule_display': next_schedule_display,
    }
    
    return render(request, 'intake_verification.html', context)


@csrf_exempt
def detect_gesture(request):
    """Detect hand-to-mouth gesture from a single frame"""
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=400)
    
    try:
        data = json.loads(request.body)
        image_data = data.get('image')
        schedule_id = data.get('schedule_id')
        
        print(f"📸 Detection request - schedule_id: {schedule_id}")
        
        if not image_data:
            return JsonResponse({'status': 'error', 'message': 'Missing image'}, status=400)
        
        if image_data.startswith('data:image/jpeg;base64,'):
            image_data = image_data.replace('data:image/jpeg;base64,', '')
        elif image_data.startswith('data:image/png;base64,'):
            image_data = image_data.replace('data:image/png;base64,', '')
        
        try:
            image_bytes = base64.b64decode(image_data)
            nparr = np.frombuffer(image_bytes, np.uint8)
            frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': f'Failed to decode image: {str(e)}'}, status=400)
        
        if frame is None:
            return JsonResponse({'status': 'error', 'message': 'Invalid image data'}, status=400)
        
        if not initialize_mediapipe():
            return JsonResponse({'status': 'error', 'message': 'Failed to initialize detection'}, status=500)
        
        # Get detection results with landmarks
        pill_detected, mouth_center, hand_landmarks, face_landmarks, distance = detect_hand_to_mouth_with_landmarks(frame)
        
        # Calculate fields for the frontend
        hand_detected = hand_landmarks is not None
        mouth_detected = face_landmarks is not None
        gesture_detected = pill_detected
        
        print(f"🔍 Detection: hand={hand_detected}, mouth={mouth_detected}, gesture={gesture_detected}, distance={distance}")
        
        if pill_detected and schedule_id:
            try:
                schedule = Schedule.objects.get(id=schedule_id)
                print(f"✅ Found schedule: {schedule.medication.name}")
                
                if schedule.medication.pills_remaining < schedule.medication.dosage_count:
                    print(f"❌ Not enough pills. Remaining: {schedule.medication.pills_remaining}")
                    return JsonResponse({
                        'status': 'success',
                        'hand_detected': hand_detected,
                        'mouth_detected': mouth_detected,
                        'gesture_detected': gesture_detected,
                        'hand_landmarks': hand_landmarks,
                        'face_landmarks': face_landmarks,
                        'distance': distance,
                        'verified': False,
                        'message': 'Not enough pills remaining'
                    })
                
                if schedule.intake_status == 'verified':
                    print(f"⚠️ Already verified: {schedule.medication.name}")
                    return JsonResponse({
                        'status': 'success',
                        'hand_detected': hand_detected,
                        'mouth_detected': mouth_detected,
                        'gesture_detected': gesture_detected,
                        'hand_landmarks': hand_landmarks,
                        'face_landmarks': face_landmarks,
                        'distance': distance,
                        'verified': False,
                        'message': 'Already verified'
                    })
                
                now = timezone.now()
                scheduled_datetime = datetime.combine(date.today(), schedule.scheduled_time)
                scheduled_datetime = timezone.make_aware(scheduled_datetime)
                time_diff_minutes = (now - scheduled_datetime).total_seconds() / 60
                
                if time_diff_minutes > 60:
                    print(f"⚠️ Too late! {time_diff_minutes} minutes past.")
                    return JsonResponse({
                        'status': 'success',
                        'hand_detected': hand_detected,
                        'mouth_detected': mouth_detected,
                        'gesture_detected': gesture_detected,
                        'hand_landmarks': hand_landmarks,
                        'face_landmarks': face_landmarks,
                        'distance': distance,
                        'verified': False,
                        'message': 'Medication window expired'
                    })
                
                is_late = time_diff_minutes > 15 and time_diff_minutes <= 60
                status = 'late' if is_late else 'on_time'
                
                schedule.medication.dispense()
                schedule.intake_status = 'verified'
                schedule.last_verified_take = now
                schedule.save()
                
                print(f"✅ Pill dispensed. New remaining: {schedule.medication.pills_remaining}")
                
                IntakeLog.objects.create(
                    schedule=schedule,
                    medication=schedule.medication,
                    scheduled_time=scheduled_datetime,
                    actual_take_time=now,
                    status=status,
                    is_verified=True,
                    verification_method='camera',
                    camera_confirmed=True,
                    detection_confidence=0.95,
                    minutes_late=int(time_diff_minutes) if time_diff_minutes > 0 else 0,
                    notes=f'Verified via hand-to-mouth detection. {"Late" if is_late else "On time"}'
                )
                
                print(f"✅ Intake log created with status: {status}")
                
                return JsonResponse({
                    'status': 'success',
                    'hand_detected': hand_detected,
                    'mouth_detected': mouth_detected,
                    'gesture_detected': gesture_detected,
                    'hand_landmarks': hand_landmarks,
                    'face_landmarks': face_landmarks,
                    'distance': distance,
                    'verified': True,
                    'is_late': is_late,
                    'message': f'✅ Pill intake verified for {schedule.medication.name} {"(Late)" if is_late else ""}'
                })
                
            except Schedule.DoesNotExist:
                print(f"❌ Schedule not found with ID: {schedule_id}")
                return JsonResponse({
                    'status': 'success',
                    'hand_detected': hand_detected,
                    'mouth_detected': mouth_detected,
                    'gesture_detected': gesture_detected,
                    'hand_landmarks': hand_landmarks,
                    'face_landmarks': face_landmarks,
                    'distance': distance,
                    'verified': False,
                    'message': 'Schedule not found'
                })
            except Exception as e:
                print(f"❌ Error: {e}")
                import traceback
                traceback.print_exc()
                return JsonResponse({
                    'status': 'success',
                    'hand_detected': hand_detected,
                    'mouth_detected': mouth_detected,
                    'gesture_detected': gesture_detected,
                    'hand_landmarks': hand_landmarks,
                    'face_landmarks': face_landmarks,
                    'distance': distance,
                    'verified': False,
                    'message': str(e)
                })
        
        return JsonResponse({
            'status': 'success',
            'hand_detected': hand_detected,
            'mouth_detected': mouth_detected,
            'gesture_detected': gesture_detected,
            'hand_landmarks': hand_landmarks,
            'face_landmarks': face_landmarks,
            'distance': distance,
            'verified': False
        })
        
    except json.JSONDecodeError as e:
        print(f"❌ JSON decode error: {e}")
        return JsonResponse({'status': 'error', 'message': 'Invalid JSON data'}, status=400)
    except Exception as e:
        print(f"❌ Error in detect_gesture: {e}")
        import traceback
        traceback.print_exc()
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    
def detect_hand_to_mouth_with_landmarks(frame):
    """Detect hand-to-mouth gesture with landmarks and distance"""
    global hand_landmarker, face_landmarker
    
    if hand_landmarker is None or face_landmarker is None:
        return False, None, None, None, None
    
    try:
        INDEX_TIP = 8
        WRIST = 0
        THUMB_TIP = 4
        PINKY_TIP = 20
        
        h, w = frame.shape[:2]
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
        
        hand_result = hand_landmarker.detect(mp_image)
        face_result = face_landmarker.detect(mp_image)
        
        mouth_center = None
        pill_detected = False
        hand_landmarks_list = None
        face_landmarks_list = None
        distance = None
        
        # Get face landmarks
        if face_result and face_result.face_landmarks:
            face_landmarks = face_result.face_landmarks[0]
            face_landmarks_list = []
            for lm in face_landmarks:
                face_landmarks_list.append({
                    'x': lm.x * w,
                    'y': lm.y * h,
                    'z': lm.z
                })
            
            left_corner = face_landmarks[78]
            right_corner = face_landmarks[308]
            upper_lip = face_landmarks[13]
            lower_lip = face_landmarks[14]
            
            mouth_center = (
                int(((left_corner.x + right_corner.x) / 2) * w),
                int(((upper_lip.y + lower_lip.y) / 2) * h)
            )
        
        # Get hand landmarks
        if hand_result and hand_result.hand_landmarks and mouth_center:
            for hand_lms in hand_result.hand_landmarks:
                hand_landmarks_list = []
                for lm in hand_lms:
                    hand_landmarks_list.append({
                        'x': lm.x * w,
                        'y': lm.y * h,
                        'z': lm.z
                    })
                
                index_tip = hand_lms[INDEX_TIP]
                finger_pos = (int(index_tip.x * w), int(index_tip.y * h))
                
                distance = np.sqrt((finger_pos[0] - mouth_center[0])**2 + 
                                  (finger_pos[1] - mouth_center[1])**2)
                
                threshold = w * 0.08
                if distance < threshold:
                    pill_detected = True
                    break
        
        return pill_detected, mouth_center, hand_landmarks_list, face_landmarks_list, distance
        
    except Exception as e:
        print(f"Detection error: {e}")
        return False, None, None, None, None


@csrf_exempt
def verify_intake(request):
    """Verify pill intake manually"""
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'}, status=400)
    
    try:
        data = json.loads(request.body)
        schedule_id = data.get('schedule_id')
        
        if not schedule_id:
            return JsonResponse({'status': 'error', 'message': 'Missing schedule ID'}, status=400)
        
        schedule = get_object_or_404(Schedule, id=schedule_id)
        
        if schedule.medication.pills_remaining < schedule.medication.dosage_count:
            return JsonResponse({
                'status': 'error',
                'message': 'Not enough pills remaining. Please refill.'
            }, status=400)
        
        # Check if taken late
        now = timezone.now()
        scheduled_datetime = datetime.combine(date.today(), schedule.scheduled_time)
        scheduled_datetime = timezone.make_aware(scheduled_datetime)
        time_diff_minutes = (now - scheduled_datetime).total_seconds() / 60
        
        # Determine if it's on time or late
        is_late = time_diff_minutes > 15
        status = 'late' if is_late else 'on_time'
        
        # Dispense the pill (this decreases pills_remaining)
        schedule.medication.dispense()
        schedule.intake_status = 'verified'
        schedule.last_verified_take = now
        schedule.save()
        
        # Create intake log
        IntakeLog.objects.create(
            schedule=schedule,
            medication=schedule.medication,
            scheduled_time=scheduled_datetime,
            actual_take_time=now,
            status=status,
            is_verified=True,
            verification_method='manual',
            minutes_late=int(time_diff_minutes) if time_diff_minutes > 0 else 0,
            notes=f'Verified manually. {"Late" if is_late else "On time"}'
        )
        
        return JsonResponse({
            'status': 'success',
            'is_late': is_late,
            'message': f'✅ Pill intake verified for {schedule.medication.name} {"(Late)" if is_late else ""}'
        })
        
    except Schedule.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Schedule not found'}, status=404)
    except Exception as e:
        print(f"Error in verify_intake: {e}")
        return JsonResponse({'status': 'error', 'message': str(e)}, status=500)


# ==================== REMOVAL FUNCTIONS ====================

@csrf_protect
def request_remove_medication(request, schedule_id):
    """Request caregiver approval to remove a medication"""
    schedule = get_object_or_404(Schedule, id=schedule_id)
    
    if request.method == 'POST':
        approval_token = secrets.token_urlsafe(32)
        
        request.session['pending_removal_id'] = schedule.id
        request.session['pending_removal_token'] = approval_token
        
        approval_url = request.build_absolute_uri(
            reverse('approve_removal', args=[approval_token, schedule_id])
        )
        denial_url = request.build_absolute_uri(
            reverse('deny_removal', args=[approval_token, schedule_id])
        )
        
        if getattr(settings, 'CAREGIVER_EMAIL', None):
            try:
                send_mail(
                    subject=f'[SmartCare] Removal Request: {schedule.medication.name}',
                    message=f"""
A request has been made to remove {schedule.medication.name} from the schedule.

Please review and approve or deny this request:

✅ Approve Removal: {approval_url}
❌ Deny Removal: {denial_url}
                    """,
                    from_email=settings.EMAIL_HOST_USER,
                    recipient_list=[settings.CAREGIVER_EMAIL],
                    fail_silently=True,
                )
            except Exception as e:
                print(f"Email error: {e}")
        
        messages.warning(request, 
            f"⚠️ Removal request for {schedule.medication.name} has been sent to your caregiver.")
        return redirect('schedule')
    
    return redirect('schedule')


def approve_removal(request, token, schedule_id):
    """Caregiver approval for removal"""
    schedule = get_object_or_404(Schedule, id=schedule_id)
    
    if request.method == 'POST':
        schedule.status = 'completed'
        schedule.save()
        messages.success(request, f"✅ {schedule.medication.name} has been removed from schedule.")
        return redirect('schedule')
    
    context = {
        'schedule': schedule,
        'token': token,
    }
    return render(request, 'approve_removal.html', context)


def deny_removal(request, token, schedule_id):
    """Caregiver denial for removal"""
    schedule = get_object_or_404(Schedule, id=schedule_id)
    messages.info(request, f"❌ Removal of {schedule.medication.name} has been denied by caregiver.")
    return redirect('schedule')


# ==================== MEDICATION FUNCTIONS ====================

@csrf_protect
def add_medication(request):
    """Step 1: Check interactions before saving - supports 1-3 daily times"""
    if request.method != 'POST':
        return redirect('schedule')
    
    today = date.today()
    existing_schedules = Schedule.objects.filter(
        status='active',
        start_date__lte=today,
        medication__pills_remaining__gt=0
    ).select_related('medication')
    
    existing_drugs = list(set([s.medication.name.lower().strip() for s in existing_schedules]))
    new_medication_name = request.POST.get('name', '').lower().strip()
    
    all_drugs = existing_drugs + [new_medication_name]
    interactions = check_drug_interactions(all_drugs)
    
    # Get schedule times
    dose_count = int(request.POST.get('dose_count', 1))
    times = []
    for i in range(1, dose_count + 1):
        time_str = request.POST.get(f'time_{i}', '').strip()
        if time_str:
            try:
                time_obj = datetime.strptime(time_str, '%H:%M').time()
                times.append(time_obj)
            except ValueError:
                try:
                    time_obj = datetime.strptime(time_str, '%I:%M %p').time()
                    times.append(time_obj)
                except ValueError:
                    pass
    
    start_date_str = request.POST.get('start_date')
    start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date() if start_date_str else date.today()
    
    # Store times as string for pending
    times_str = ', '.join([t.strftime('%H:%M') for t in times])
    first_time = times[0] if times else None
    
    if interactions:
        approval_token = secrets.token_urlsafe(32)
        
        pending = PendingMedication.objects.create(
            name=request.POST.get('name'),
            generic_name=request.POST.get('generic_name', ''),
            category=request.POST.get('category', ''),
            instructions=request.POST.get('instructions', ''),
            dosage_count=int(request.POST.get('dosage_count', 1)),
            total_pills_loaded=int(request.POST.get('total_pills_loaded', 0)),
            low_quantity_threshold=int(request.POST.get('low_quantity_threshold', 5)),
            meal_instruction=request.POST.get('meal_instruction', 'any'),
            scheduled_time=first_time,
            start_date=start_date,
            multiple_times=times_str,
            interactions_found=json.dumps(interactions),
            approval_token=approval_token,
            status='pending'
        )
        
        approval_url = request.build_absolute_uri(
            reverse('approve_medication', args=[approval_token])
        )
        denial_url = request.build_absolute_uri(
            reverse('deny_medication', args=[approval_token])
        )
        
        interaction_summary = "\n".join([
            f"- {i['drug1']} + {i['drug2']}: {i['description'][:100]}..."
            for i in interactions
        ])
        
        if getattr(settings, 'CAREGIVER_EMAIL', None):
            try:
                send_mail(
                    subject=f'[SmartCare] Medication Approval Required: {request.POST.get("name")}',
                    message=f"""
A new medication ({request.POST.get('name')}) has been requested but has potential interactions with existing medications.

INTERACTIONS DETECTED:
{interaction_summary}

Schedule Times: {times_str if times_str else 'Not specified'}

Please review and approve or deny this request:

✅ Approve: {approval_url}
❌ Deny: {denial_url}

This request will expire in 48 hours.
                    """,
                    from_email=settings.EMAIL_HOST_USER,
                    recipient_list=[settings.CAREGIVER_EMAIL],
                    fail_silently=True,
                )
            except Exception as e:
                print(f"Email error: {e}")
        
        request.session['pending_medication_id'] = pending.id
        request.session['interactions'] = interactions
        request.session['multiple_times'] = times_str
        
        messages.warning(request, 
            f"⚠️ {request.POST.get('name')} has potential interactions. "
            f"An approval request has been sent to your caregiver.")
        return redirect('pending_approval')
    
    return save_medication_directly(request)


def save_medication_directly(request):
    """Save medication without caregiver approval - supports 1-3 daily times"""
    total_pills = int(request.POST.get('total_pills_loaded', 0))
    
    medication = Medication.objects.create(
        name=request.POST.get('name'),
        generic_name=request.POST.get('generic_name', ''),
        category=request.POST.get('category', ''),
        instructions=request.POST.get('instructions', ''),
        dosage_count=int(request.POST.get('dosage_count', 1)),
        total_pills_loaded=total_pills,
        pills_remaining=total_pills,
        low_quantity_threshold=int(request.POST.get('low_quantity_threshold', 5)),
        meal_instruction=request.POST.get('meal_instruction', 'any'),
    )
    
    start_date_str = request.POST.get('start_date')
    start_date = datetime.strptime(start_date_str, '%Y-%m-%d').date() if start_date_str else date.today()
    
    # Get number of doses per day
    dose_count = int(request.POST.get('dose_count', 1))
    
    # Collect times from form fields
    times = []
    for i in range(1, dose_count + 1):
        time_str = request.POST.get(f'time_{i}', '').strip()
        if time_str:
            try:
                time_obj = datetime.strptime(time_str, '%H:%M').time()
                times.append(time_obj)
            except ValueError:
                try:
                    time_obj = datetime.strptime(time_str, '%I:%M %p').time()
                    times.append(time_obj)
                except ValueError:
                    messages.error(request, f"Invalid time format for Time {i}")
                    return redirect('schedule')
    
    if not times:
        messages.error(request, "Please enter at least one valid time.")
        return redirect('schedule')
    
    # Sort times
    times.sort()
    
    # Create a schedule for each time
    created_count = 0
    for idx, time_obj in enumerate(times):
        Schedule.objects.create(
            medication=medication,
            scheduled_time=time_obj,
            start_date=start_date,
            status='active',
            dose_number=idx + 1,
            group_id=f"{medication.id}_{start_date}_{idx}"
        )
        created_count += 1
    
    messages.success(request, f"✅ {medication.name} added with {created_count} daily dose(s).")
    return redirect('schedule')


def pending_approval(request):
    """Show pending approval status page"""
    pending_id = request.session.get('pending_medication_id')
    interactions = request.session.get('interactions', [])
    
    if not pending_id:
        return redirect('schedule')
    
    try:
        pending = PendingMedication.objects.get(id=pending_id)
    except PendingMedication.DoesNotExist:
        return redirect('schedule')
    
    context = {
        'pending': pending,
        'interactions': interactions,
    }
    return render(request, 'pending_approval.html', context)


def approve_medication(request, token):
    """Caregiver approval endpoint - supports multiple times"""
    try:
        pending = PendingMedication.objects.get(approval_token=token, status='pending')
    except PendingMedication.DoesNotExist:
        messages.error(request, "Invalid or expired approval link.")
        return redirect('schedule')
    
    if request.method == 'POST':
        medication = Medication.objects.create(
            name=pending.name,
            generic_name=pending.generic_name,
            category=pending.category,
            instructions=pending.instructions,
            dosage_count=pending.dosage_count,
            total_pills_loaded=pending.total_pills_loaded,
            pills_remaining=pending.total_pills_loaded,
            low_quantity_threshold=pending.low_quantity_threshold,
            meal_instruction=pending.meal_instruction,
        )
        
        start_date = pending.start_date
        
        # Get times from multiple_times field or use scheduled_time
        times_str = pending.multiple_times
        times = []
        
        if times_str:
            for time_str in times_str.split(','):
                time_str = time_str.strip()
                if time_str:
                    try:
                        time_obj = datetime.strptime(time_str, '%H:%M').time()
                        times.append(time_obj)
                    except ValueError:
                        try:
                            time_obj = datetime.strptime(time_str, '%I:%M %p').time()
                            times.append(time_obj)
                        except ValueError:
                            pass
        
        # Fallback to scheduled_time if no times found
        if not times and pending.scheduled_time:
            times = [pending.scheduled_time]
        
        if not times:
            messages.error(request, "No valid schedule times found.")
            return redirect('schedule')
        
        times.sort()
        
        for idx, time_obj in enumerate(times):
            Schedule.objects.create(
                medication=medication,
                scheduled_time=time_obj,
                start_date=start_date,
                status='active',
                dose_number=idx + 1,
                group_id=f"{medication.id}_{start_date}_{idx}"
            )
        
        pending.status = 'approved'
        pending.approved_at = timezone.now()
        pending.save()
        
        request.session.pop('pending_medication_id', None)
        request.session.pop('interactions', None)
        request.session.pop('multiple_times', None)
        
        messages.success(request, f"✅ {pending.name} has been approved with {len(times)} daily dose(s).")
        return redirect('schedule')
    
    context = {
        'pending': pending,
        'interactions': json.loads(pending.interactions_found),
    }
    return render(request, 'approve_medication.html', context)


def deny_medication(request, token):
    """Caregiver denial endpoint"""
    try:
        pending = PendingMedication.objects.get(approval_token=token, status='pending')
    except PendingMedication.DoesNotExist:
        messages.error(request, "Invalid or expired denial link.")
        return redirect('schedule')
    
    pending.status = 'denied'
    pending.save()
    
    request.session.pop('pending_medication_id', None)
    request.session.pop('interactions', None)
    
    messages.info(request, f"❌ {pending.name} has been denied by caregiver.")
    return redirect('schedule')


def mark_taken(request, schedule_id):
    """Mark a pill as taken"""
    if request.method == 'POST':
        schedule = get_object_or_404(Schedule, id=schedule_id)
        
        if schedule.medication.dispense():
            schedule.intake_status = 'verified'
            schedule.last_verified_take = timezone.now()
            schedule.save()
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'status': 'success', 'message': 'Marked as taken'})
            
            messages.success(request, f"Marked {schedule.medication.name} as taken.")
            return redirect('schedule')
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'status': 'error', 'message': 'Not enough pills remaining'}, status=400)
            messages.error(request, f"Not enough pills remaining for {schedule.medication.name}.")
            return redirect('schedule')
    
    return redirect('schedule')


def get_schedule_api(request, date_str=None):
    """API endpoint to get schedule for a specific date"""
    if date_str:
        target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
    else:
        target_date = date.today()
    
    all_schedules = Schedule.objects.filter(
        status='active',
        start_date__lte=target_date,
        medication__pills_remaining__gt=0
    ).select_related('medication')
    
    active_schedules = [s for s in all_schedules if s.is_active_today(target_date)]
    
    result = []
    for s in active_schedules:
        result.append({
            'id': s.id,
            'scheduled_time': s.scheduled_time.strftime('%H:%M'),
            'status': s.status,
            'medication_name': s.medication.name,
            'dosage_count': s.medication.dosage_count,
            'pills_remaining': s.medication.pills_remaining,
            'instructions': s.medication.instructions,
            'dose_number': s.dose_number,
        })
    
    return JsonResponse(result, safe=False)


# ==================== CLEAR OLD SCHEDULES (Optional) ====================

@csrf_protect
def clear_old_schedules(request):
    """Clear schedules older than today"""
    if request.method == 'POST':
        today = date.today()
        old_schedules = Schedule.objects.filter(start_date__lt=today)
        count = old_schedules.count()
        old_schedules.delete()
        return JsonResponse({'status': 'success', 'message': f'Deleted {count} old schedules'})
    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)


# ==================== NOTIFICATION STATUS API ====================

def get_notification_data_json(request):
    """API endpoint for notification status."""
    try:
        today = date.today()
        now = timezone.now()
        
        # Get the next pending schedule
        schedule = Schedule.objects.filter(
            status='active',
            start_date__lte=today,
            medication__pills_remaining__gt=0,
            intake_status='pending'
        ).order_by('scheduled_time').first()
        
        if schedule and schedule.is_active_today(today):
            # Check if in verification window
            scheduled_datetime = datetime.combine(today, schedule.scheduled_time)
            scheduled_datetime = timezone.make_aware(scheduled_datetime)
            time_diff_minutes = (now - scheduled_datetime).total_seconds() / 60
            
            if -5 <= time_diff_minutes <= 60:
                return JsonResponse({'status': 'pending'})
            elif time_diff_minutes > 60:
                # Check if already marked as missed
                if schedule.intake_status == 'missed':
                    return JsonResponse({'status': 'missed'})
                return JsonResponse({'status': 'pending'})
        
        # Check if any schedule is verified today
        verified_today = Schedule.objects.filter(
            status='active',
            start_date__lte=today,
            intake_status='verified'
        ).exists()
        
        if verified_today:
            return JsonResponse({'status': 'verified'})
        
        return JsonResponse({'status': 'none'})
        
    except Exception as e:
        print(f"Error in notification status: {e}")
        return JsonResponse({'status': 'error'})