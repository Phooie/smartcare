import cv2
import time
import csv
import os
from datetime import datetime

class LiveEvaluator:
    def __init__(self, detector):
        self.detector = detector
        self.results = []
        self.frame_times = []
        
    def run_test(self, duration=60, save_video=False):
        """Run live evaluation for specified duration"""
        
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("❌ Could not open webcam")
            return
        
        # Optional: save video for later review
        if save_video:
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
            out = cv2.VideoWriter(f'evaluation_{datetime.now().strftime("%Y%m%d_%H%M%S")}.avi', 
                                  fourcc, 20.0, (640, 480))
        
        print("🎥 Starting live evaluation...")
        print("📋 Perform these actions:")
        print("   - Put hand near mouth (pill taking)")
        print("   - Put hand away from mouth")
        print("   - Repeat for 60 seconds")
        print("   - Press 'q' to quit early")
        print("=" * 40)
        
        start_time = time.time()
        frame_count = 0
        hand_near_count = 0
        detection_success_count = 0
        
        while time.time() - start_time < duration:
            ret, frame = cap.read()
            if not ret:
                break
            
            frame_start = time.time()
            
            # Run detection
            hand_pos, mouth_pos = self.detector.detect(frame)
            is_near = self.detector.is_hand_near_mouth(hand_pos, mouth_pos)
            
            elapsed = time.time() - frame_start
            self.frame_times.append(elapsed)
            
            # Record results
            self.results.append({
                'frame': frame_count,
                'hand_detected': hand_pos is not None,
                'mouth_detected': mouth_pos is not None,
                'hand_near_mouth': is_near,
                'hand_x': hand_pos[0] if hand_pos else None,
                'hand_y': hand_pos[1] if hand_pos else None,
                'mouth_x': mouth_pos[0] if mouth_pos else None,
                'mouth_y': mouth_pos[1] if mouth_pos else None,
                'timestamp': time.time() - start_time,
                'processing_time': elapsed * 1000  # ms
            })
            
            # Counts
            frame_count += 1
            if hand_pos and mouth_pos:
                detection_success_count += 1
            if is_near:
                hand_near_count += 1
            
            # Show overlay
            display_frame = frame.copy()
            status_text = "🟢 HAND NEAR" if is_near else "🔴 HAND AWAY"
            if not hand_pos or not mouth_pos:
                status_text = "⚠️ DETECTING..."
            
            cv2.putText(display_frame, f"Status: {status_text}", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(display_frame, f"Frames: {frame_count}", (10, 60),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            cv2.putText(display_frame, f"Time: {time.time() - start_time:.1f}s", (10, 90),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
            
            # Show detected points
            if hand_pos:
                cv2.circle(display_frame, (int(hand_pos[0]), int(hand_pos[1])), 10, (0, 255, 0), -1)
            if mouth_pos:
                cv2.circle(display_frame, (int(mouth_pos[0]), int(mouth_pos[1])), 10, (0, 0, 255), -1)
            
            cv2.imshow("Live Evaluation - Press 'q' to quit", display_frame)
            
            if save_video:
                out.write(display_frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                print("⏹️ Stopped early by user")
                break
        
        cap.release()
        if save_video:
            out.release()
        cv2.destroyAllWindows()
        
        print("\n✅ Test completed!")
        print(f"   Frames processed: {frame_count}")
        print(f"   Total time: {time.time() - start_time:.1f} seconds")
        
        self.display_results()
        self.save_results()
    
    def display_results(self):
        """Calculate and display metrics"""
        
        total = len(self.results)
        if total == 0:
            print("No results to display")
            return
        
        hand_detected = sum(1 for r in self.results if r['hand_detected'])
        mouth_detected = sum(1 for r in self.results if r['mouth_detected'])
        both_detected = sum(1 for r in self.results if r['hand_detected'] and r['mouth_detected'])
        hand_near = sum(1 for r in self.results if r['hand_near_mouth'])
        
        # Speed metrics
        avg_fps = total / sum(self.frame_times) if self.frame_times else 0
        avg_latency = sum(self.frame_times) / len(self.frame_times) * 1000 if self.frame_times else 0
        
        print("\n" + "=" * 50)
        print("📊 EVALUATION RESULTS")
        print("=" * 50)
        print(f"\n📈 SPEED:")
        print(f"   Average FPS: {avg_fps:.1f}")
        print(f"   Average Latency: {avg_latency:.1f} ms")
        
        print(f"\n🎯 DETECTION:")
        print(f"   Hand Detection Rate: {hand_detected/total*100:.1f}% ({hand_detected}/{total})")
        print(f"   Mouth Detection Rate: {mouth_detected/total*100:.1f}% ({mouth_detected}/{total})")
        print(f"   Both Detected Rate: {both_detected/total*100:.1f}% ({both_detected}/{total})")
        
        print(f"\n🔄 PROXIMITY:")
        print(f"   Hand Near Mouth: {hand_near/total*100:.1f}% ({hand_near}/{total})")
        print(f"   Hand Not Near Mouth: {(total-hand_near)/total*100:.1f}% ({total-hand_near}/{total})")
        print("=" * 50)
    
    def save_results(self):
        """Save results to CSV"""
        filename = f'evaluation_results_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        
        with open(filename, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=self.results[0].keys())
            writer.writeheader()
            writer.writerows(self.results)
        
        print(f"\n💾 Results saved to: {filename}")

# Usage
from .views import HandMouthDetector

detector = HandMouthDetector()
evaluator = LiveEvaluator(detector)
evaluator.run_test(duration=60, save_video=True)